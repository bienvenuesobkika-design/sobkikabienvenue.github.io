SITE OFFICIEL — SOBKIKA BIENVENUE

1. Ouvrir index.html pour prévisualiser le site.
2. Remplacer VOTRE-DOMAINE.example par le vrai nom de domaine après achat/hébergement.
3. Ajouter vos liens sociaux officiels dans la page.
4. Ajouter une photo professionnelle si souhaité.
5. Mettre le site en ligne sur un hébergeur.
6. Après publication, utiliser Google Search Console pour demander l'indexation.
7. Garder partout le nom « SOBKIKA Bienvenue » et l'appellation « Spécialiste en études internationales et stratégiques ».

Le balisage ProfilePage/Person est déjà intégré dans index.html.
